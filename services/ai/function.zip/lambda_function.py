import json

def generate_research_email(lab_info):
    """Generate a research email based on lab information."""
    professor = lab_info['professors'][0]  # Get the first professor for now
    
    email_template = f"""Subject: Undergraduate Research Opportunity Inquiry - {lab_info['name']}

Dear {professor['name']},

I hope this email finds you well. My name is [Your Name], and I am a [Your Year] student at [Your University] majoring in [Your Major].

I am writing to express my interest in research opportunities at the {lab_info['name']}. I was particularly drawn to your work in {lab_info['researchArea']}, especially [mention specific research or publication that interests you].

{lab_info['description']} This aligns perfectly with my academic interests and career goals in [relevant field].

During my studies, I have completed coursework in [relevant courses] and have developed skills in [relevant skills]. I have also [mention any relevant projects, experience, or achievements].

I would greatly appreciate the opportunity to discuss potential research positions in your lab, whether for course credit, as a volunteer, or as a paid position. I am available to meet at your convenience to further discuss how my background and interests might contribute to your research.

Thank you for considering my inquiry. I have attached my resume for your review, and I look forward to the possibility of working with you.

Sincerely,
[Your Name]
[Your Contact Information]"""

    return email_template

def lambda_handler(event, context):
    # Add CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',  # Allow requests from any origin
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
        'Content-Type': 'application/json'
    }

    # Handle OPTIONS request for CORS preflight
    if event['httpMethod'] == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({})
        }

    try:
        # Verify API key
        api_key = event.get('headers', {}).get('x-api-key')
        expected_api_key = 'hbTJHKmAzW31KclNxEbAOaIMopgsitk73CM0iZYY'
        
        if not api_key or api_key != expected_api_key:
            return {
                'statusCode': 401,
                'headers': headers,
                'body': json.dumps({
                    'status': 'error',
                    'message': 'Invalid API key'
                })
            }

        # Parse request body
        body = json.loads(event.get('body', '{}'))
        lab_info = body.get('labInfo', {})

        if not lab_info:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'status': 'error',
                    'message': 'Missing lab information'
                })
            }

        # Generate email
        email = generate_research_email(lab_info)

        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'status': 'success',
                'message': email
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'status': 'error',
                'message': str(e)
            })
        } 